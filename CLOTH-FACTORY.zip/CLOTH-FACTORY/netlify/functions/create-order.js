exports.handler = async (event) => {
  // सिर्फ POST रिक्वेस्ट स्वीकार करें
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: 'Method Not Allowed' })
    };
  }

  try {
    const { orderAmount, customerPhone, customerName } = JSON.parse(event.body);

    // Netlify Environment Variables से Keys लोड होंगी
    const appId = process.env.CASHFREE_APP_ID;
    const secretKey = process.env.CASHFREE_SECRET_KEY;
    const env = process.env.CASHFREE_ENV || 'production';

    // लाइव या टेस्ट URL का चयन
    const baseUrl = env === 'sandbox' 
      ? 'https://sandbox.cashfree.com/pg/orders' 
      : 'https://api.cashfree.com/pg/orders';

    const orderId = 'CF_' + Date.now();

    const cfResponse = await fetch(baseUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-client-id': appId,
        'x-client-secret': secretKey,
        'x-api-version': '2023-08-01'
      },
      body: JSON.stringify({
        order_id: orderId,
        order_amount: Number(orderAmount),
        order_currency: 'INR',
        customer_details: {
          customer_id: 'CUST_' + customerPhone,
          customer_name: customerName || 'Valued Customer',
          customer_phone: customerPhone
        }
      })
    });

    const data = await cfResponse.json();

    if (!cfResponse.ok) {
      return {
        statusCode: cfResponse.status,
        body: JSON.stringify({ error: data.message || 'Cashfree Order Failed' })
      };
    }

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ payment_session_id: data.payment_session_id })
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message })
    };
  }
};